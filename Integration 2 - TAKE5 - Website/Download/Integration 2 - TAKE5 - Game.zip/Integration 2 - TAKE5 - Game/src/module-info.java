open module Take5 {
    requires javafx.controls;
    requires javafx.media;
    requires javafx.base;
    requires javafx.graphics;
    requires java.sql;

}